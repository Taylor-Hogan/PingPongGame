


Instructions:

	Red Paddle: 	pres "w" to move paddle up
			press "s" to move paddle down

	Blue Paddle: 	pres "Up arrow" to move paddle up
			press "Down Arrow" to move paddle down

	Score:		Every past ball is a point for the opposite side

	Gametime:	The game time is unlimited. Play until you want to quit.
	
	To play:
	** must have python 2.5 or later insatlled ***
		- Download PongGame Folder
		- Place it in desired direcrtory
		- cd..  to your python or project folder
		- cd PongGame
		- pong.py
		- game starts



Bugs:
Red paddle deflection is not accurate. 